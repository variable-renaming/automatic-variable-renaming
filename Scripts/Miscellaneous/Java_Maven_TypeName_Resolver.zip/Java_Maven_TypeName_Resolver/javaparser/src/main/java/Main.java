import com.github.javaparser.*;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.ImportDeclaration;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.body.*;
import com.github.javaparser.ast.expr.*;
import com.github.javaparser.ast.stmt.ExplicitConstructorInvocationStmt;
import com.github.javaparser.ast.type.*;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;
import com.github.javaparser.printer.lexicalpreservation.LexicalPreservingPrinter;
import com.github.javaparser.symbolsolver.*;
import com.github.javaparser.symbolsolver.resolution.typesolvers.CombinedTypeSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.JarTypeSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.JavaParserTypeSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.ReflectionTypeSolver;


import java.io.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.io.File;
import java.io.IOException;
import com.google.gson.Gson;

public class Main{


    private static String FILE_PATH = "";
    private static String SRC_PATH = "";
    private final static Logger LOGGER = Logger.getLogger(Main.class.getName());

    private static <T, E> Set<T> getKeysByValue(Map<T, E> map, E value) {
        return map.entrySet()
                .stream()
                .filter(entry -> Objects.equals(entry.getValue(), value))
                .map(Map.Entry::getKey)
                .collect(Collectors.toSet());
    }


    public static String visitMethod(MethodDeclaration m) {

        List<String> tokens = new ArrayList<>();
        for (JavaToken t : m.getTokenRange().get()) {
            if (t.getCategory().name().equals("EOL") || t.getCategory().name().equals("WHITESPACE_NO_EOL")) {
                continue;
            } else {
                tokens.add(t.getText());

            }
        }
        // Handling annotation
        NodeList<AnnotationExpr> annotationExpr = m.getAnnotations();
        int starting_line = -1;
        if (annotationExpr.size() > 0) {
            starting_line = annotationExpr.get(0).getBegin().get().line;
        } else {
            starting_line = m.getRange().get().begin.line;
        }

        return "" + starting_line + "," + m.getRange().get().end.line + "," + m.getNameAsString() + "," + tokens.size();
    }


    // The solution I came up with here, tackles cases in which there are nested classes in a singlejava file and multiple classes as well
    /*
        File Class.java
        public class A{
         ......
        }

        public class B{
         .....
        }
        For this example the resolver will return a two distinct objects (one for class A and one for class B)
     */
    public static void listClasses(File projectDir, String outputLogFolder, ArrayList<String> brokenFiles) throws IOException {

        String statFile = outputLogFolder + "/ResolvingStats.csv";
        FileWriter stats = new FileWriter(statFile);
        stats.write("File,JP-Solved,HP-Solved,Tot" + "\n");

        String unparsedFiles = outputLogFolder + "/unparsedFiles.txt";
        FileWriter unparsed = new FileWriter(unparsedFiles);

        String completed_class = outputLogFolder + "/completed_classes.txt";
        FileWriter completedClass = new FileWriter(completed_class, true);
        ArrayList<String> completedJavaFiles =  new ArrayList<>();

        try {

            Scanner s = new Scanner(new File(completed_class));

            while (s.hasNext()) {
                completedJavaFiles.add(s.next());
            }
            s.close();
        }catch (Exception FileNotFoundException){

        }

        AtomicReference<String> pathExternal =  new AtomicReference<>();

        new DirExplorer((level, path, file) -> path.endsWith(".java"), (level, path, file) -> {

            //System.out.println(path);
            StaticJavaParser.getConfiguration().setAttributeComments(false);
            CompilationUnit cu = null;
            try {
                cu = StaticJavaParser.parse(file);
                LexicalPreservingPrinter.setup(cu);
                pathExternal.set(path);

            }catch(com.github.javaparser.ParseProblemException e){

                unparsed.write(projectDir + pathExternal.get() + "\n");
                return;
            }
            //System.out.println(cu.toString());

            // Note: Since the parser changes the formatting we have to make sure to work on that specific version, namely .JP
            //System.out.println(cu);
            String[] splitted_items = path.split("/");
            String javaFname = splitted_items[splitted_items.length - 1];

            String newJavaFname = file.toString().replace(javaFname, javaFname.replace(".java", ".JP"));
            FileWriter new_parsed_Java_file = new FileWriter(newJavaFname);
            new_parsed_Java_file.write(cu.toString());
            new_parsed_Java_file.close();

            CompilationUnit cu_parsed = StaticJavaParser.parse(new File(newJavaFname));
            LexicalPreservingPrinter.setup(cu_parsed);

            List<Result> results = new ArrayList<>();

            String outputJsonFile = (projectDir + path).replace(".java", ".json").replace("large-scale-repos-mvn-compilable", "large-scale-repos-mvn-compilable-json");

            FileWriter aaa = new FileWriter(statFile);
            aaa.write(path + "\n");
            aaa.close();


            new VoidVisitorAdapter<Object>() {

                @Override
                public void visit(ClassOrInterfaceDeclaration n, Object arg) {

                    super.visit(n, arg);
                    String className = n.getName().asString();

                    if (brokenFiles.contains(projectDir + path)) {
                        try {
                            unparsed.write(projectDir + path + "\n");
                            return;
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }

                    if (completedJavaFiles.contains(projectDir + path)) {
                        return;
                    }


                    HashMap<String, String> mapResolvedType = new HashMap<>();
                    Optional<ClassOrInterfaceDeclaration> targetClass = cu_parsed.getClassByName(className);

                    ArrayList idLines = new ArrayList<Integer>();
                    ArrayList resolvedIdentifiers = new ArrayList<String>();
                    ArrayList identifiers = new ArrayList<String>();
                    ArrayList<Method> methodList = new ArrayList<>();

                    try {

                        List<MethodDeclaration> methods = targetClass.get().getMethods();
                        for (MethodDeclaration m : methods) {

                            String method_info = visitMethod(m);

                            String[] splitted_result = method_info.split(",");

                            int lower_bound = Integer.valueOf(splitted_result[0]);
                            int upper_bound = Integer.valueOf(splitted_result[1]);
                            String method_name = splitted_result[2];
                            int number_of_tokens = Integer.valueOf(splitted_result[3]);

                            if (number_of_tokens >= 513) {
                                FileWriter longer = new FileWriter(outputLogFolder + "/DiscardedMethods.txt", true);
                                longer.write("From: " + javaFname + "  discarding: " + method_name + "\n");
                                longer.close();
                                continue;
                            } else {
                                methodList.add(new Method(method_name, m.toString(), lower_bound, upper_bound, number_of_tokens));
                            }
                        }
                    } catch (Exception NoSuchElementException) {
                        methodList = null;
                    }

                    try {
                        int class_declaration_line = targetClass.get().getBegin().get().line;
                        for (JavaToken javaToken : targetClass.get().getTokenRange().get()) {

                            // Only keep track in the table of IDENTIFIER TOKEN
                            if (javaToken.getKind() == 94) {

                                int startingColumn = javaToken.getRange().get().begin.column;
                                //int endingColumn = javaToken.getRange().get().end.column;
                                int startingLine = javaToken.getRange().get().begin.line - class_declaration_line + 1;

                                String token = javaToken.getText();
                                String key = "<token>" + token + "</token>" + "<st_line>" + startingLine + "</st_line>" + "<st_column>" + startingColumn + "</st_column>";
                                mapResolvedType.put(key, "");

                            }
                        }


                        try {
                            resolveClass(new File(newJavaFname), projectDir.toString(), mapResolvedType, class_declaration_line, stats, outputJsonFile, results);
                            Iterator it = mapResolvedType.entrySet().iterator();
                            while (it.hasNext()) {
                                Map.Entry pair = (Map.Entry) it.next();
                                if (pair.getValue().equals("")) {
                                    it.remove();
                                }
                            }

                            it = mapResolvedType.entrySet().iterator();

                            while (it.hasNext()) {
                                Map.Entry pair = (Map.Entry) it.next();

                                String key = (String) pair.getKey();
                                String resolved = (String) pair.getValue();

                                Pattern pattern_token = Pattern.compile("<token>(.+?)</token>", Pattern.DOTALL);
                                Pattern pattern_idLine = Pattern.compile("<st_line>(.+?)</st_line>", Pattern.DOTALL);

                                Matcher matcher_token = pattern_token.matcher(key);
                                Matcher matcher_idLine = pattern_idLine.matcher(key);

                                matcher_token.find();
                                matcher_idLine.find();
                                String token = matcher_token.group(1);
                                String idLine = matcher_idLine.group(1);

                                idLines.add(idLine);
                                identifiers.add(token);
                                resolvedIdentifiers.add(resolved);

                            }

                            results.add(new Result(targetClass.get().toString(), newJavaFname, identifiers, resolvedIdentifiers, idLines, methodList));
                            completedClass.write(projectDir + path + "\n");
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    } catch (Exception NoSuchElementExpection) {
                        System.out.println();
                    }

                }
            }.visit(StaticJavaParser.parse(new File(newJavaFname)), null);
            System.out.println(); // empty line

            try {
                Gson gson = new Gson();
                String json_result = gson.toJson(results);
                if (json_result.length() > 2) {
                    FileWriter file_res = new FileWriter(outputJsonFile);
                    //System.out.println(json_result);
                    file_res.write(json_result);
                    file_res.close();
                } else {
                    FileWriter empty = new FileWriter(outputLogFolder + "/EmptyClasses.txt", true);
                    empty.write(path);
                    empty.close();
                }

            } catch (IOException e) {
                //exception handling left as an exercise for the reader
            }


        }).explore(projectDir);
        stats.close();
        completedClass.close();
        unparsed.close();
    }



    public static void resolveClass(File pathSpecific, String project, HashMap<String, String> mapResolvedType, int class_declaration_line, FileWriter stats, String outputJsonFile, List<Result> results) throws IOException {

        // This resolver only works for MVN projects.
        // First, you need to compile the project, then you have to make sure to resolve all the dependencies. Take a look at the script.sh file
        String jar_combined_file = project + "/my_lib_folder/combined.jar";

        Pattern pattern = Pattern.compile("/src/.*?/java", Pattern.CASE_INSENSITIVE);

        Matcher matcher = pattern.matcher(pathSpecific.toString());

        Map<String, String> string_imports = new HashMap<>();

        LOGGER.info("Starting on " + pathSpecific);

        int heuristicallySolved = 0;
        int JPSolved = 0;

        if (matcher.find()) {

            SRC_PATH = pathSpecific.toString().substring(0, matcher.end());

            CombinedTypeSolver combinedSolver = new CombinedTypeSolver
                    (
                            new JavaParserTypeSolver(new File(SRC_PATH)),
                            new ReflectionTypeSolver(),
                            new JarTypeSolver(jar_combined_file)
                    );

            JavaSymbolSolver symbolSolver = new JavaSymbolSolver(combinedSolver);
            StaticJavaParser.getConfiguration().setSymbolResolver(symbolSolver);
            CompilationUnit cu = StaticJavaParser.parse(pathSpecific);
            LexicalPreservingPrinter.setup(cu);


            //https://www.javadoc.io/doc/com.github.javaparser/javaparser-core/3.8.3/com/github/javaparser/resolution/class-use/Resolvable.html

            // EXPR resolvable types
            //List<MarkerAnnotationExpr> markerAnnotationExprs = cu.findAll(MarkerAnnotationExpr.class);
            //List<NormalAnnotationExpr> normalAnnotationExprs = cu.findAll(NormalAnnotationExpr.class);
            List<AnnotationExpr> annotationExprs = cu.findAll(AnnotationExpr.class);
            List<MethodCallExpr> methodCallExprs = cu.findAll(MethodCallExpr.class);
            List<MethodReferenceExpr> methodReferenceExprs = cu.findAll(MethodReferenceExpr.class);
            List<NameExpr> nameExprs = cu.findAll(NameExpr.class);
            List<ObjectCreationExpr> objectCreationExprs = cu.findAll(ObjectCreationExpr.class);
            List<FieldAccessExpr> fieldAccessExprs = cu.findAll(FieldAccessExpr.class);
            List<ThisExpr> thisExprs = cu.findAll(ThisExpr.class);

            // BODY resolvable types
            List<AnnotationDeclaration> annotations = cu.findAll(AnnotationDeclaration.class);
            List<AnnotationMemberDeclaration> annotationMemberDeclarations = cu.findAll(AnnotationMemberDeclaration.class);
            List<ClassOrInterfaceDeclaration> classOrInterfaceDeclarations = cu.findAll(ClassOrInterfaceDeclaration.class);
            List<ConstructorDeclaration> constructorDeclarations = cu.findAll(ConstructorDeclaration.class);
            List<EnumConstantDeclaration> enumConstantDeclarations = cu.findAll(EnumConstantDeclaration.class);
            List<EnumDeclaration> enums = cu.findAll(EnumDeclaration.class);
            List<FieldDeclaration> fieldDeclarations = cu.findAll(FieldDeclaration.class);
            List<VariableDeclarator> variables = cu.findAll(VariableDeclarator.class);
            List<MethodDeclaration> methods = cu.findAll(MethodDeclaration.class);
            List<Parameter> parameters = cu.findAll(Parameter.class);
            List<ImportDeclaration> imports = cu.findAll(ImportDeclaration.class);

            // STMT resolvable types
            List<ExplicitConstructorInvocationStmt> explicitConstructorInvocationStmts = cu.findAll(ExplicitConstructorInvocationStmt.class);

            List<Type> types = cu.findAll(Type.class);


            for (ImportDeclaration import_declaration : imports) {
                String string_declaration = import_declaration.getName().asString();
                int p = string_declaration.lastIndexOf(".");
                String ff = string_declaration.substring(p + 1);
                string_imports.put(string_declaration, ff);

            }

            // Since the javaparser contains a shallow bug (e.g. String.format(...) "String" cannot be solved) I came up with my own fix
            string_imports.put("java.lang.String", "String");
            string_imports.put("java.lang.Class", "Class");
            string_imports.put("java.lang.ClassLoader", "ClassLoader");
            string_imports.put("java.lang.Cloneable", "Cloneable");
            string_imports.put("java.lang.Compiler", "Compiler");
            string_imports.put("java.lang.Double", "Double");
            string_imports.put("java.lang.Float", "Float");
            string_imports.put("java.lang.Integer", "Integer");
            string_imports.put("java.lang.Long", "Long");
            string_imports.put("java.lang.Math", "Math");
            string_imports.put("java.lang.Number", "Number");
            string_imports.put("java.lang.Object", "Object");
            string_imports.put("java.lang.Process", "Process");
            string_imports.put("java.lang.Runnable", "Runnable");
            string_imports.put("java.lang.Runtime", "Runtime");
            string_imports.put("java.lang.SecurityManager", "SecurityManager");
            string_imports.put("java.lang.Short", "Short");
            string_imports.put("java.lang.StringBuffer", "StringBuffer");
            string_imports.put("java.lang.System", "System");
            string_imports.put("java.lang.Thread", "Thread");
            string_imports.put("java.lang.ThreadGroup", "ThreadGroup");
            string_imports.put("java.lang.Throwable", "Throwable");
            string_imports.put("java.lang.Void", "Void");


            for (MethodDeclaration methodDeclaration : methods) {

                int starting_line = methodDeclaration.getNameAsExpression().getBegin().get().line - class_declaration_line + 1;
                int starting_column = methodDeclaration.getNameAsExpression().getBegin().get().column;
                int ending_column = methodDeclaration.getNameAsExpression().getEnd().get().column;


                try {
                    String resolved = methodDeclaration.resolve().getQualifiedName();
                    String methodName = methodDeclaration.getNameAsString();
                    String key = "<token>" + methodName + "</token>" + "<st_line>" + starting_line + "</st_line>" + "<st_column>" + starting_column + "</st_column>";
                    if (mapResolvedType.containsKey(key)) {
                        mapResolvedType.put(key, resolved);
                        JPSolved += 1;
                    }

                } catch (Exception e) {

                    String partialType = methodDeclaration.getNameAsString();
                    if (string_imports.containsValue(partialType)) {
                        Set<String> fetchedKey = getKeysByValue(string_imports, partialType);

                        String t = methodDeclaration.getNameAsString();
                        String key = "<token>" + t + "</token>" + "<st_line>" + starting_line + "</st_line>" + "<st_column>" + starting_column + "</st_column>";

                        String retrieved = (String) fetchedKey.toArray()[0];
                        mapResolvedType.put(key, retrieved);
                        heuristicallySolved += 1;

                    }
                }

            }

            // With type we catch all kind of types
            for (Type type : types) {
                int starting_line = -1;
                try {

                    starting_line = type.getBegin().get().line - class_declaration_line + 1;
                    int starting_column = type.getBegin().get().column;
                    int ending_column = type.getEnd().get().column;


                    try {
                        String resolved = type.resolve().describe();

                        String key = "<token>" + type.asString() + "</token>" + "<st_line>" + starting_line + "</st_line>" + "<st_column>" + starting_column + "</st_column>";

                        if (mapResolvedType.containsKey(key)) {
                            mapResolvedType.put(key, resolved);
                            JPSolved += 1;

                        }

                    } catch (Exception e) {

                        String partialType = type.toString();
                        if (string_imports.containsValue(partialType)) {
                            Set<String> fetchedKey = getKeysByValue(string_imports, partialType);

                            String t = type.toString();
                            String key = "<token>" + t + "</token>" + "<st_line>" + starting_line + "</st_line>" + "<st_column>" + starting_column + "</st_column>";

                            String retrieved = (String) fetchedKey.toArray()[0];
                            mapResolvedType.put(key, retrieved);
                            heuristicallySolved += 1;

                        }
                    }
                } catch (Exception e1) {

                }
            }

            for (ExplicitConstructorInvocationStmt explicitConstructorInvocationStmt : explicitConstructorInvocationStmts) {

                int starting_line = explicitConstructorInvocationStmt.getBegin().get().line - class_declaration_line + 1;
                int starting_column = explicitConstructorInvocationStmt.getBegin().get().column;
                int ending_column = explicitConstructorInvocationStmt.getEnd().get().column;


                try {
                    String resolved = explicitConstructorInvocationStmt.resolve().getQualifiedName();

                    String key = "<token>" + explicitConstructorInvocationStmt.toString() + "</token>" + "<st_line>" + starting_line + "</st_line>" + "<st_column>" + starting_column + "</st_column>";
                    mapResolvedType.put(key, resolved);

                    if (mapResolvedType.containsKey(key)) {
                        mapResolvedType.put(key, resolved);
                        JPSolved += 1;

                    }


                } catch (Exception e) {

                    String partialType = explicitConstructorInvocationStmt.toString();
                    if (string_imports.containsValue(partialType)) {
                        Set<String> fetchedKey = getKeysByValue(string_imports, partialType);

                        String t = explicitConstructorInvocationStmt.toString();
                        String key = "<token>" + t + "</token>" + "<st_line>" + starting_line + "</st_line>" + "<st_column>" + starting_column + "</st_column>";

                        String retrieved = (String) fetchedKey.toArray()[0];
                        mapResolvedType.put(key, retrieved);
                        heuristicallySolved += 1;

                    }
                }

            }


            for (ConstructorDeclaration constructorDeclaration : constructorDeclarations) {
                int starting_line = constructorDeclaration.getNameAsExpression().getName().getBegin().get().line - class_declaration_line + 1;
                int starting_column = constructorDeclaration.getNameAsExpression().getName().getBegin().get().column;
                int ending_column = constructorDeclaration.getNameAsExpression().getName().getEnd().get().column;

                try {
                    String resolved = constructorDeclaration.resolve().getQualifiedName();

                    String key = "<token>" + constructorDeclaration.getNameAsExpression().getName().getIdentifier() + "</token>" + "<st_line>" + starting_line + "</st_line>" + "<st_column>" + starting_column + "</st_column>";
                    if (mapResolvedType.containsKey(key)) {
                        mapResolvedType.put(key, resolved);
                        JPSolved += 1;

                    }


                } catch (Exception e) {

                    String partialType = constructorDeclaration.getDeclarationAsString();
                    if (string_imports.containsValue(partialType)) {
                        Set<String> fetchedKey = getKeysByValue(string_imports, partialType);

                        String t = constructorDeclaration.toString();
                        String key = "<token>" + t + "</token>" + "<st_line>" + starting_line + "</st_line>" + "<st_column>" + starting_column + "</st_column>";

                        String retrieved = (String) fetchedKey.toArray()[0];
                        mapResolvedType.put(key, retrieved);
                        heuristicallySolved += 1;

                    }
                }
            }


            for (EnumDeclaration enumDeclaration : enums) {

                int starting_line = enumDeclaration.getBegin().get().line - class_declaration_line + 1;
                int starting_column = enumDeclaration.getBegin().get().column;
                int ending_column = enumDeclaration.getEnd().get().column;


                try {
                    String resolved = enumDeclaration.resolve().getQualifiedName();

                    String key = "<token>" + enumDeclaration.getNameAsString() + "</token>" + "<st_line>" + starting_line + "</st_line>" + "<st_column>" + starting_column + "</st_column>";
                    if (mapResolvedType.containsKey(key)) {
                        mapResolvedType.put(key, resolved);
                        JPSolved += 1;

                    }


                } catch (Exception e) {

                    String partialType = enumDeclaration.getNameAsString();
                    if (string_imports.containsValue(partialType)) {
                        Set<String> fetchedKey = getKeysByValue(string_imports, partialType);

                        String t = enumDeclaration.toString();
                        String key = "<token>" + t + "</token>" + "<st_line>" + starting_line + "</st_line>" + "<st_column>" + starting_column + "</st_column>";

                        String retrieved = (String) fetchedKey.toArray()[0];
                        mapResolvedType.put(key, retrieved);
                        heuristicallySolved += 1;

                    }
                }

            }

            for (EnumConstantDeclaration enumConstantDeclaration : enumConstantDeclarations) {

                int starting_line = enumConstantDeclaration.getBegin().get().line - class_declaration_line + 1;
                int starting_column = enumConstantDeclaration.getBegin().get().column;
                int ending_column = enumConstantDeclaration.getEnd().get().column;

                try {
                    String resolved = enumConstantDeclaration.resolve().getType().describe();

                    String key = "<token>" + enumConstantDeclaration.getName().getIdentifier() + "</token>" + "<st_line>" + starting_line + "</st_line>" + "<st_column>" + starting_column + "</st_column>";
                    if (mapResolvedType.containsKey(key)) {
                        mapResolvedType.put(key, resolved);
                        JPSolved += 1;

                    }


                } catch (Exception e) {

                    String partialType = enumConstantDeclaration.getNameAsString();
                    if (string_imports.containsValue(partialType)) {
                        Set<String> fetchedKey = getKeysByValue(string_imports, partialType);

                        String t = enumConstantDeclaration.toString();
                        String key = "<token>" + t + "</token>" + "<st_line>" + starting_line + "</st_line>" + "<st_column>" + starting_column + "</st_column>";

                        String retrieved = (String) fetchedKey.toArray()[0];
                        mapResolvedType.put(key, retrieved);
                        heuristicallySolved += 1;

                    }

                }

            }

            for (ThisExpr thisExpr : thisExprs) {

                int starting_line = thisExpr.getBegin().get().line - class_declaration_line + 1;
                int starting_column = thisExpr.getBegin().get().column;
                int ending_column = thisExpr.getEnd().get().column;

                try {
                    String resolved = thisExpr.resolve().getQualifiedName();

                    String key = "<token>" + thisExpr.asThisExpr().toString() + "</token>" + "<st_line>" + starting_line + "</st_line>" + "<st_column>" + starting_column + "</st_column>";
                    mapResolvedType.put(key, resolved);
                    JPSolved += 1;

                } catch (Exception e) {

                    String partialType = thisExpr.toString();
                    if (string_imports.containsValue(partialType)) {
                        Set<String> fetchedKey = getKeysByValue(string_imports, partialType);

                        String t = thisExpr.toString();
                        String key = "<token>" + t + "</token>" + "<st_line>" + starting_line + "</st_line>" + "<st_column>" + starting_column + "</st_column>";

                        String retrieved = (String) fetchedKey.toArray()[0];
                        mapResolvedType.put(key, retrieved);
                        heuristicallySolved += 1;

                    }
                }

            }

            for (AnnotationDeclaration annotation : annotations) {

                int starting_line = annotation.getBegin().get().line - class_declaration_line + 1;
                int starting_column = annotation.getBegin().get().column;
                int ending_column = annotation.getEnd().get().column;

                try {
                    String resolved = annotation.resolve().getName();

                    String key = "<token>" + annotation.getNameAsString() + "</token>" + "<st_line>" + starting_line + "</st_line>" + "<st_column>" + starting_column + "</st_column>";
                    if (mapResolvedType.containsKey(key)) {
                        mapResolvedType.put(key, resolved);
                        JPSolved += 1;

                    }

                } catch (Exception e) {

                    String partialType = annotation.toString();
                    if (string_imports.containsValue(partialType)) {
                        Set<String> fetchedKey = getKeysByValue(string_imports, partialType);

                        String t = annotation.toString();
                        String key = "<token>" + t + "</token>" + "<st_line>" + starting_line + "</st_line>" + "<st_column>" + starting_column + "</st_column>";

                        String retrieved = (String) fetchedKey.toArray()[0];
                        mapResolvedType.put(key, retrieved);
                        heuristicallySolved += 1;

                    }
                }

            }


            for (AnnotationMemberDeclaration annotation : annotationMemberDeclarations) {

                int starting_line = annotation.getBegin().get().line - class_declaration_line + 1;
                int starting_column = annotation.getBegin().get().column;
                int ending_column = annotation.getEnd().get().column;


                try {
                    String resolved = annotation.resolve().getName();

                    String key = "<token>" + annotation.getNameAsString() + "</token>" + "<st_line>" + starting_line + "</st_line>" + "<st_column>" + starting_column + "</st_column>";
                    mapResolvedType.put(key, resolved);
                    if (mapResolvedType.containsKey(key)) {
                        mapResolvedType.put(key, resolved);
                        JPSolved += 1;

                    }

                } catch (Exception e) {

                    String partialType = annotation.toString();
                    if (string_imports.containsValue(partialType)) {
                        Set<String> fetchedKey = getKeysByValue(string_imports, partialType);

                        String t = annotation.toString();
                        String key = "<token>" + t + "</token>" + "<st_line>" + starting_line + "</st_line>" + "<st_column>" + starting_column + "</st_column>";

                        String retrieved = (String) fetchedKey.toArray()[0];
                        mapResolvedType.put(key, retrieved);
                        heuristicallySolved += 1;

                    }
                }

            }

            //ok
            for (ClassOrInterfaceDeclaration classOrInterfaceDeclaration : classOrInterfaceDeclarations) {

                int starting_line = classOrInterfaceDeclaration.getBegin().get().line - class_declaration_line + 1;
                int starting_column = classOrInterfaceDeclaration.getBegin().get().column;
                int ending_column = classOrInterfaceDeclaration.getEnd().get().column;


                try {
                    String resolved = classOrInterfaceDeclaration.resolve().getQualifiedName();

                    String key = "<token>" + classOrInterfaceDeclaration.getName().getIdentifier() + "</token>" + "<st_line>" + starting_line + "</st_line>" + "<st_column>" + starting_column + "</st_column>";
                    mapResolvedType.put(key, resolved);
                    if (mapResolvedType.containsKey(key)) {
                        mapResolvedType.put(key, resolved);
                        JPSolved += 1;

                    }


                } catch (Exception e) {

                    String partialType = classOrInterfaceDeclaration.toString();
                    if (string_imports.containsValue(partialType)) {
                        Set<String> fetchedKey = getKeysByValue(string_imports, partialType);

                        String t = classOrInterfaceDeclaration.toString();
                        String key = "<token>" + t + "</token>" + "<st_line>" + starting_line + "</st_line>" + "<st_column>" + starting_column + "</st_column>";

                        String retrieved = (String) fetchedKey.toArray()[0];
                        mapResolvedType.put(key, retrieved);
                        heuristicallySolved += 1;

                    }
                }

            }

            for (AnnotationExpr annotation : annotationExprs) {

                int starting_line = annotation.getBegin().get().line - class_declaration_line + 1;
                int starting_column = annotation.getBegin().get().column;
                int ending_column = annotation.getEnd().get().column;

                try {
                    String resolved = annotation.resolve().getQualifiedName();

                    String key = "<token>" + annotation.getNameAsString() + "</token>" + "<st_line>" + starting_line + "</st_line>" + "<st_column>" + starting_column + "</st_column>";
                    mapResolvedType.put(key, resolved);
                    if (mapResolvedType.containsKey(key)) {
                        mapResolvedType.put(key, resolved);
                        JPSolved += 1;

                    }

                } catch (Exception e) {

                    // We might want to try to resolve with the heuristic if javaparser fails
                    final String partialType = annotation.getName().getIdentifier();

                    if (string_imports.containsValue(partialType)) {
                        Set<String> fetchedKey = getKeysByValue(string_imports, partialType);

                        String t = annotation.toString();
                        String key = "<token>" + partialType + "</token>" + "<st_line>" + starting_line + "</st_line>" + "<st_column>" + starting_column + "</st_column>";

                        String retrieved = (String) fetchedKey.toArray()[0];
                        mapResolvedType.put(key, retrieved);
                        heuristicallySolved += 1;

                    }
                }

            }

            //ok
            for (VariableDeclarator variable : variables) {

                int starting_line = variable.getBegin().get().line  - class_declaration_line + 1;
                int starting_column = variable.getBegin().get().column;


                try {
                    String resolved = variable.resolve().getType().describe();
                    String key = "<token>" + variable.getNameAsString() + "</token>" + "<st_line>" + starting_line + "</st_line>" + "<st_column>" + starting_column + "</st_column>" ;
                    mapResolvedType.put(key, resolved);
                    if (mapResolvedType.containsKey(key)) {
                        mapResolvedType.put(key, resolved);
                        JPSolved+=1;
                    }

                } catch (Exception e) {

                    String partialType = variable.getTypeAsString();
                    if (string_imports.containsValue(partialType)) {
                        Set<String> fetchedKey = getKeysByValue(string_imports, partialType);

                        String t = variable.getNameAsString();
                        String key = "<token>" + t + "</token>" + "<st_line>" + starting_line + "</st_line>" + "<st_column>" + starting_column + "</st_column>" ;
                        String retrieved = (String) fetchedKey.toArray()[0];
                        mapResolvedType.put(key, retrieved);
                        heuristicallySolved += 1;

                    }
                }

            }


            for (ObjectCreationExpr objectCreationExpr : objectCreationExprs) {

                int starting_line = objectCreationExpr.getBegin().get().line - class_declaration_line + 1;
                int starting_column = objectCreationExpr.getBegin().get().column;
                int ending_column = objectCreationExpr.getEnd().get().column;

                String object_name = objectCreationExpr.getTypeAsString();

                try {
                    String resolved = objectCreationExpr.resolve().getQualifiedName();

                    String key = "<token>" + object_name + "</token>" + "<st_line>" + starting_line + "</st_line>" + "<st_column>" + starting_column + "</st_column>";
                    mapResolvedType.put(key, resolved);
                    if (mapResolvedType.containsKey(key)) {
                        mapResolvedType.put(key, resolved);
                        JPSolved += 1;

                    }

                } catch (Exception e) {

                    String partialType = objectCreationExpr.getTypeAsString();
                    if (string_imports.containsValue(partialType)) {
                        Set<String> fetchedKey = getKeysByValue(string_imports, partialType);

                        String t = objectCreationExpr.getType().getName().getIdentifier();
                        String key = "<token>" + t + "</token>" + "<st_line>" + starting_line + "</st_line>" + "<st_column>" + starting_column + "</st_column>";

                        String retrieved = (String) fetchedKey.toArray()[0];
                        mapResolvedType.put(key, retrieved);
                        heuristicallySolved += 1;

                    }
                }

            }

            for (FieldAccessExpr fieldAccessExpr : fieldAccessExprs) {

                int starting_line = fieldAccessExpr.getBegin().get().line - class_declaration_line + 1;
                int starting_column = fieldAccessExpr.getBegin().get().column;
                int ending_column = fieldAccessExpr.getEnd().get().column;

                try {

                    String resolved = fieldAccessExpr.resolve().getType().describe();
                    String field = fieldAccessExpr.getName().getIdentifier();
                    int firstDotPosition = fieldAccessExpr.toString().indexOf(".");
                    String leftHandSide = fieldAccessExpr.toString().substring(0, firstDotPosition);
                    String key = "<token>" + leftHandSide + "</token>" + "<st_line>" + starting_line + "</st_line>" + "<st_column>" + starting_column + "</st_column>";
                    mapResolvedType.put(key, resolved);
                    if (mapResolvedType.containsKey(key)) {
                        mapResolvedType.put(key, resolved);
                        JPSolved += 1;

                    }

                } catch (Exception e) {

                    String partialType = fieldAccessExpr.toString();
                    if (string_imports.containsValue(partialType)) {
                        Set<String> fetchedKey = getKeysByValue(string_imports, partialType);

                        int firstDotPosition = fieldAccessExpr.toString().indexOf(".");
                        String t = fieldAccessExpr.toString().substring(0, firstDotPosition);
                        String key = "<token>" + t + "</token>" + "<st_line>" + starting_line + "</st_line>" + "<st_column>" + starting_column + "</st_column>";

                        String retrieved = (String) fetchedKey.toArray()[0];
                        mapResolvedType.put(key, retrieved);
                        heuristicallySolved += 1;

                    }
                }

            }

            for (MethodReferenceExpr methodReferenceExpr : methodReferenceExprs) {

                int starting_line = methodReferenceExpr.getBegin().get().line - class_declaration_line + 1;
                int starting_column = methodReferenceExpr.getBegin().get().column;
                int ending_column = methodReferenceExpr.getEnd().get().column;

                try {

                    String resolved = methodReferenceExpr.resolve().getQualifiedName();
                    String key = "<token>" + methodReferenceExpr.getIdentifier() + "</token>" + "<st_line>" + starting_line + "</st_line>" + "<st_column>" + starting_column + "</st_column>";
                    mapResolvedType.put(key, resolved);
                    if (mapResolvedType.containsKey(key)) {
                        mapResolvedType.put(key, resolved);
                        JPSolved += 1;

                    }

                } catch (Exception e) {

                    String partialType = methodReferenceExpr.getIdentifier();
                    if (string_imports.containsValue(partialType)) {
                        Set<String> fetchedKey = getKeysByValue(string_imports, partialType);

                        String t = methodReferenceExpr.toString();
                        String key = "<token>" + t + "</token>" + "<st_line>" + starting_line + "</st_line>" + "<st_column>" + starting_column + "</st_column>";

                        String retrieved = (String) fetchedKey.toArray()[0];
                        mapResolvedType.put(key, retrieved);
                        heuristicallySolved += 1;

                    }
                }

            }

            //ok
            for (FieldDeclaration fieldDeclaration : fieldDeclarations) {

                for (VariableDeclarator variable : fieldDeclaration.getVariables()) {

                    int starting_line = variable.getBegin().get().line - class_declaration_line + 1;
                    int starting_column = variable.getBegin().get().column;
                    int ending_column = variable.getEnd().get().column;

                    String var_name = variable.getNameAsString();

                    try {
                        String resolved = variable.resolve().getType().describe();
                        String key = "<token>" + var_name + "</token>" + "<st_line>" + starting_line + "</st_line>" + "<st_column>" + starting_column + "</st_column>";
                        mapResolvedType.put(key, resolved);
                        if (mapResolvedType.containsKey(key)) {
                            mapResolvedType.put(key, resolved);
                            JPSolved += 1;

                        }


                    } catch (Exception e) {

                        String partialType = fieldDeclaration.toString();
                        if (string_imports.containsValue(partialType)) {
                            Set<String> fetchedKey = getKeysByValue(string_imports, partialType);

                            String key = "<token>" + var_name + "</token>" + "<st_line>" + starting_line + "</st_line>" + "<st_column>" + starting_column + "</st_column>";

                            String retrieved = (String) fetchedKey.toArray()[0];
                            mapResolvedType.put(key, retrieved);
                            heuristicallySolved += 1;


                        }
                    }
                }

            }

            //ok
            for (NameExpr nameExpr : nameExprs) {

                int starting_line = nameExpr.getBegin().get().line - class_declaration_line + 1;
                int starting_column = nameExpr.getBegin().get().column;
                int ending_column = nameExpr.getEnd().get().column;


                try {

                    String resolved = nameExpr.resolve().getType().describe();
                    String nameExpression = nameExpr.getName().asString();
                    String key = "<token>" + nameExpression + "</token>" + "<st_line>" + starting_line + "</st_line>" + "<st_column>" + starting_column + "</st_column>";
                    mapResolvedType.put(key, resolved);
                    if (mapResolvedType.containsKey(key)) {
                        mapResolvedType.put(key, resolved);
                        JPSolved += 1;

                    }


                } catch (Exception e) {

                    String partialType = nameExpr.getNameAsString();
                    if (string_imports.containsValue(partialType)) {

                        Set<String> fetchedKey = getKeysByValue(string_imports, partialType);

                        String t = nameExpr.getNameAsString();
                        String key = "<token>" + t + "</token>" + "<st_line>" + starting_line + "</st_line>" + "<st_column>" + starting_column + "</st_column>";

                        String retrieved = (String) fetchedKey.toArray()[0];

                        mapResolvedType.put(key, retrieved);
                        heuristicallySolved += 1;

                    }
                }

            }

            //ok
            for (MethodCallExpr methodCallExpr : methodCallExprs) {

                int starting_line = methodCallExpr.getBegin().get().line - class_declaration_line + 1;
                int starting_column = methodCallExpr.getBegin().get().column;
                int ending_column = methodCallExpr.getEnd().get().column;

                String method_name = methodCallExpr.getName().asString();

                try {
                    String resolved = methodCallExpr.resolve().declaringType().getQualifiedName();
                    String key = "<token>" + method_name + "</token>" + "<st_line>" + starting_line + "</st_line>" + "<st_column>" + starting_column + "</st_column>";
                    mapResolvedType.put(key, resolved);
                    if (mapResolvedType.containsKey(key)) {
                        mapResolvedType.put(key, resolved);
                        JPSolved += 1;

                    }


                } catch (Exception e) {

                    String partialType = methodCallExpr.getNameAsString();
                    if (string_imports.containsValue(partialType)) {
                        Set<String> fetchedKey = getKeysByValue(string_imports, partialType);

                        String t = methodCallExpr.getNameAsString();
                        String key = "<token>" + t + "</token>" + "<st_line>" + starting_line + "</st_line>" + "<st_column>" + starting_column + "</st_column>";

                        String retrieved = (String) fetchedKey.toArray()[0];
                        mapResolvedType.put(key, retrieved);
                        heuristicallySolved += 1;

                    }
                }

            }


            //ok
            for (Parameter parameter : parameters) {

                int starting_line = parameter.getBegin().get().line - class_declaration_line + 1;
                int starting_column = parameter.getBegin().get().column;
                int ending_column = parameter.getEnd().get().column;


                try {

                    String resolved = parameter.resolve().getType().describe();
                    String key = "<token>" + parameter.getNameAsString() + "</token>" + "<st_line>" + starting_line + "</st_line>" + "<st_column>" + starting_column + "</st_column>";
                    mapResolvedType.put(key, resolved);
                    if (mapResolvedType.containsKey(key)) {
                        mapResolvedType.put(key, resolved);
                        JPSolved += 1;

                    }

                } catch (Exception e) {

                    String partialType = parameter.getTypeAsString();
                    if (string_imports.containsValue(partialType)) {
                        Set<String> fetchedKey = getKeysByValue(string_imports, partialType);


                        String t = parameter.getNameAsString();
                        String key = "<token>" + t + "</token>" + "<st_line>" + starting_line + "</st_line>" + "<st_column>" + starting_column + "</st_column>";
                        String retrieved = (String) fetchedKey.toArray()[0];
                        mapResolvedType.put(key, retrieved);
                        heuristicallySolved += 1;

                    }
                }
            }

            stats.write(pathSpecific + "," + JPSolved + "," + heuristicallySolved + "," + (JPSolved + heuristicallySolved) + "\n");
            //log here how many java file we didn't parse correctly
            LOGGER.info(pathSpecific + " Correctly parsed");


            try {
                Gson gson = new Gson();
                String json_result = gson.toJson(results);
                if (json_result.length() > 2) {
                    FileWriter file_res = new FileWriter(outputJsonFile);
                    file_res.write(json_result);
                    file_res.close();
                } else {
                    FileWriter empty = new FileWriter(project + "/EmptyClasses.txt", true);
                    empty.write(pathSpecific.toString());
                    empty.close();
                }

            } catch (IOException e) {
            }


        }
        stats.write(pathSpecific+","+JPSolved+","+heuristicallySolved+","+(JPSolved+heuristicallySolved)+"\n");
    }

    public static void main(String[] args) throws Exception {

        String project = args[0];
        String processedFilesPath = args[1];
        String brokenFilesPath = args[2];

        ArrayList<String> processedJavaFiles = new ArrayList<String>();

        try {

            Scanner s = new Scanner(new File(processedFilesPath));

            while (s.hasNext()) {
                processedJavaFiles.add(s.next());
            }
            s.close();
        }catch (Exception FileNotFoundException){

        }


        // Add here all the files on which JavaParser fails, such that we do not parse those
        ArrayList<String> brokenFiles = new ArrayList<String>();

        try {

            Scanner s = new Scanner(new File(brokenFilesPath));

            while (s.hasNext()) {
                brokenFiles.add(s.next());
            }
            s.close();
        }catch (Exception FileNotFoundException){

        }

        String[] splitted = project.split("/");
        String project_folder = splitted[splitted.length-1];

        String outputLogFolder = "results/" + project_folder;

        String log_file = outputLogFolder + "/log.txt";

        FileHandler fh = new FileHandler(log_file, true);
        SimpleFormatter sf = new SimpleFormatter();
        fh.setFormatter(sf);
        LOGGER.addHandler(fh);

        listClasses(new File(project), outputLogFolder, brokenFiles);

    }

}
