import java.util.ArrayList;


public class Result {

    //private String key; // Method name + ID(considering the case in which we have multiple overrided methods)
    //private String methodBody;
    private String classBody;
    private String extracted_from;
    //private int tokens;
    private ArrayList<String> identifiers = new ArrayList<>();
    private ArrayList<Integer> idLines = new ArrayList<>();
    private ArrayList<String> resolvedIdentifiers = new ArrayList<>();
    private ArrayList<Method> methodList = new ArrayList<Method>();


//    public Result(String key, String methodBody,  int tokens, String extracted_from){
//        this.key = key;
//        this.extracted_from = extracted_from;
//        this.methodBody = methodBody;
//        this.tokens = tokens;
//    }

    public Result(String classBody, String extracted_from, ArrayList<String> identifiers, ArrayList<String> resolvedIdentifiers, ArrayList<Integer> idLines, ArrayList<Method> methodList){
        this.extracted_from = extracted_from;
        this.classBody = classBody;
        this.identifiers = identifiers;
        this.resolvedIdentifiers = resolvedIdentifiers;
        this.idLines = idLines;
        this.methodList = methodList;
    }

    public void setextracted_from(String extracted_from){
        this.extracted_from = extracted_from;
    }

    public String getextracted_from(){
        return this.extracted_from;
    }

    public ArrayList<String> getIdentifiers(){
        return this.identifiers;
    }

    /*public int getTokens(){
        return this.tokens;
    }

    public void setTokens(int tokens){
        this.tokens = tokens;
    }*/

    public ArrayList<Integer> getIdLines(){
        return this.idLines;
    }

    public ArrayList<String> getResolvedIdentifiers(){
        return this.resolvedIdentifiers;
    }


    public void setIdentifiers(ArrayList<String> items){
        this.identifiers = items;
    }

    public void setIdLines(ArrayList<Integer> items){
        this.idLines = items;
    }

    public void setResolvedIdentifers(ArrayList<String> items){
        this.resolvedIdentifiers = items;
    }

    /*public void setMethodBody(String methodBody){
        this.methodBody = methodBody;
    }*/


}
