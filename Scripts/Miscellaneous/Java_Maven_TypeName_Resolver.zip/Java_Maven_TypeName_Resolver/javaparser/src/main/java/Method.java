public class Method {

    private String methodName;
    private String methodBody;
    private int lowerBound;
    private int upperBound;
    private int numberTokens;

    public Method(String methodName, String methodBody, int lowerBound, int upperBound, int numberTokens){
        this.methodBody = methodBody;
        this.methodName = methodName;
        this.lowerBound = lowerBound;
        this.upperBound = upperBound;
        this.numberTokens = numberTokens;
    }

}
