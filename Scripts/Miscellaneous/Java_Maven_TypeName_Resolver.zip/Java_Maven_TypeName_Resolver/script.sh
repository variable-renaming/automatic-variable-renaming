#!/bin/bash

#Pipeline for stripping and joining all the jar files

echo -e "[+] STRIPPING AND JOINING $2\n" >> script_status.txt
mkdir $2/my_lib_folder
mvn -DoutputDirectory=$2/my_lib_folder dependency:copy-dependencies
find $2/my_lib_folder -name '*.jar' -exec 7z d '{}' 'META-INF/*.SF' 'META-INF/*.RSA' ';'
jar -cvf $2/my_lib_folder/combined.jar -C $2/my_lib_folder .

echo -e "[+] COMPLETED\n\n" >> script_status.txt

#################
echo -e "[+] RUN SOLVER $2\n" >> script_status.txt
mvn -e exec:java -Dexec.workingdir=$1 -Dexec.args="$2 $5 $6" -Dexec.mainClass=Main >> "$3" 2>&1
RESULT=$?
echo $RESULT > $4/exit_code.txt

echo -e "[+] COMPLETED\n" >> script_status.txt


